	<div class ="container">
		<div class="jumbotron mt-4">
			<div class= "container">
				

				<div class="row">
					<div class="col-lg-6"></div>
					<?php Flasher::flash(); ?>
				</div>



				<div class="row">
					<div class="col-lg-6">

						<button type="button" class="btn btn-primary tomboltambah" data-toggle="modal" data-target="#formModal">Tambah Data Mahasiswa</button>
						<br>

						<br><h3>Daftar Mahasiswa</h3>
						<br>
						<ul class="list-group">
							<?php foreach($data['mhs'] as $mhs): ?>
								<li class="list-group-item ">
									<?= $mhs['nama'];?>



									<a href="<?= BASEURL;?>/mahasiswa/detail/<?=$mhs['id'];?>" class="badge badge-primary float-right ml-1">detail</a>

									 <a href="<?= BASEURL;?>/mahasiswa/ubah/<?=$mhs['id'];?>" class="badge badge-success float-right tampilModalUbah  ml-1"data-toggle="modal" data-target="#formModal" data-id="<?= $mhs['id'] ;?>">ubah</a>

									 <a href="<?= BASEURL;?>/mahasiswa/cetak/<?=$mhs['id'];?>" class="badge badge-warning float-right ml-1" target="_blank">cetak</a>

									 <a href="<?= BASEURL;?>/mahasiswa/qrcode/<?=$mhs['id'];?>" class="badge badge-warning float-right ml-1" target="_blank">qrcode</a>
									 

										<a href="<?= BASEURL;?>/mahasiswa/hapus/<?= $mhs['id'];?>" class="badge badge-danger float-right ml-1" onclick="return confirm('yakin?');">Hapus</a>
								
								</li>

							<?php endforeach;?>
						</ul>




	










					</div>
				</div>
			</div>
			<br/>
		</div>
	</div>


	<div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="judulModal" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="judulModal">Tambah Data Mahasiswa</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">

					<form action="<?= BASEURL;?>/mahasiswa/tambah" method="post">

						<div class="form-group">
							<label for="nim">NIM</label>
							<input type="number" class="form-control" id="nim" name="nim">
						</div>

						<div class="form-group">
							<label for="nama">Nama</label>
							<input type="text" class="form-control" id="nama" name="nama">
						</div>

						<div class="form-group">
							<label for="asal">Asal</label>
							<input type="text" class="form-control" id="asal" name="asal">
						</div>
						<div class="form-group">
							<label for="jk">Jenis Kelamin</label>
							<select class="form-control" id="jk" name="jk">
								<option>Laki-Laki</option>
								<option>Perempuan</option>							
							</select>
						</div>

						<div class="form-group">
							<label for="jurusan">Program Studi Sains Undana</label>
							<select class="form-control" id="jurusan" name="jurusan">
								<option>Ilmu komputer</option>
								<option>Fisika</option>
								<option>Kimia</option>
								<option>Biologi</option>
								<option>Matematika</option>
							</select>
						</div>

						<div class="form-group">
							<label for="email">Email</label>
							<input type="email" class="form-control"id="email" name="email">
						</div>

						<div class="form-group">
							<label for="semester">Semester</label>
							<select class="form-control" id="semester" name="semester">
								<option>1</option>
								<option>2</option>
								<option>3</option>
								<option>4</option>
								<option>5</option>
								<option>6</option>
								<option>7</option>
								<option>8</option>
								<option>9</option>
								<option>10</option>
							</select>
						</div>
							<div class="form-group">
							<label for="alamat">Alamat</label>
							<input type="text" class="form-control"id="alamat" name="alamat">
						</div>
							<div class="form-group">
							<label for="kelurahan">Kelurahan</label>
							<input type="text" class="form-control"id="kelurahan" name="kelurahan">
						</div>

						<div class="form-group">
							<label for="kecamatan">kecamatan</label>
							<input type="text" class="form-control"id="kecamatan" name="kecamatan">
						</div>

						<div class="form-group">
							<label for="provinsi">provinsi</label>
							<input type="text" class="form-control"id="provinsi" name="provinsi">
						</div>

						<div class="form-group">
							<label for="rt">rt</label>
							<input type="number" class="form-control" id="rt" name="rt">
						</div>

						<div class="form-group">
							<label for="rw">rw</label>
							<input type="number" class="form-control" id="rw" name="rw">
						</div>

					

						<div class="form-group">
							<label for="nibu">nama ibu</label>
							<input type="text" class="form-control" id="nibu" name="nibu">
						</div>

						

							<div class="form-group">
							<label for="ayah">nama ayah</label>
							<input type="text" class="form-control" id="ayah" name="ayah">
						</div>

						

						<div class="form-group">
							<label for="bidik">bidik misi ?</label>
							<select class="form-control" id="bidik" name="bidik">
								<option>ya</option>
								<option>tidak</option>
								
							</select>
						</div>

						<div class="form-group">
							<label for="lulusan">lulusan</label>
							<input type="number" class="form-control" id="lulusan" name="lulusan">
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Tambah Data</button>
					</div>
				</div>
			</div>
		</div>