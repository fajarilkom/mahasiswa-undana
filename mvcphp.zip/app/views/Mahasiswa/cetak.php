<?php
require('C:\xampp\htdocs\mvcphp\public\pdf\rizal.php');


$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetMargins(25,20,25);

$pdf->SetFont('Arial','B',12); 
$pdf->Cell(190,30,'FORMULIR PENDAFTARAN IZIN USAHA MIKRO DAN KECIL (IUMK)',0,1,'C');

$pdf->Cell(50,10, 'NIM');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['nim'], 0,01);
?>
<?php

    include('C:\xampp\htdocs\mvcphp\public\phpqrcode\qrlib.php');
    
    // outputs image directly into browser, as PNG stream
    QRcode::png($data['mhs']['nim'],'qrcode.png');
    ?>
    <img src="C:\xampp\htdocs\mvcphp\public\qrcode.png">
