<?php

    include('C:\xampp\htdocs\mvcphp\public\phpqrcode\qrlib.php');
    
    QRcode::png($data['mhs']['nim'],'qrcode.png','H',10);
    ?>

<img src="http://localhost/MVCPHP/public/qrcode.png">


