<html>
<head>
<title> Data Mahasiswa </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <br>
  <center><h2>DATA MAHASISWA</h2>
  <p>Data Mahasiswa Diwilayah Kota Kupang</p></center>        
  <form>
  <form>
  <div class="form-row">

    <div class="form-group col-md-6">
      <label for="nama"><strong>Nama lengkap</strong></label>
      <input type="text" class="form-control"   id="nama" placeholder="<?= $data['mhs']['nama'];?>"  disabled>
    </div>

    <div class="form-group col-md-6">
     <label for="namapdk"><strong>Nim</strong></strong></label>
      <input type="text" class="form-control" id="nim" placeholder="<?= $data['mhs']['nim'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="Nama"><strong>Asal</strong></label>
      <input type="asal" class="form-control" id="asal" placeholder="<?= $data['mhs']['asal'];?>" disabled>
    </div>
    
    <div class="form-group col-md-6">
     <label for="namapanggil"><strong>Jurusan</strong></strong></label>
      <input type="Lahir" class="form-control" id="jurusan" placeholder="<?= $data['mhs']['jurusan'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="semester"><strong>Semester</strong></label>
      <input type="Umur" class="form-control" id="semester" placeholder="<?= $data['mhs']['semester'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="alamat"><strong>Jenis Kelamin</strong></label>
      <input type="text" class="form-control" id="jk" placeholder="<?= $data['mhs']['jk'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="alamat"><strong>Alamat</strong></label>
      <input type="Umur" class="form-control" id="alamat" placeholder="<?= $data['mhs']['alamat'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="kelurahan"><strong>Kelurahan</strong></label>
      <input type="text" class="form-control" id="kelurahan" placeholder="<?= $data['mhs']['kelurahan'];?>" disabled>
    </div>

    <div class="form-group col-md-6">
      <label for="kecamatan"><strong>kecamatan</strong></label>
      <input type="text" class="form-control" id="kecamatan" placeholder="<?= $data['mhs']['kecamatan'];?>" disabled>
    </div>

    <div class="form-group col-md-6">
      <label for="provinsi"><strong>provinsi</strong></label>
      <input type="text" class="form-control" id="provinsi" placeholder="<?= $data['mhs']['provinsi'];?>" disabled>
    </div>

    <div class="form-group col-md-6">
      <label for="rt"><strong>RT</strong></label>
      <input type="number" class="form-control" id="rt" placeholder="<?= $data['mhs']['rt'];?>" disabled>
    </div>

    <div class="form-group col-md-6">
      <label for="rw"><strong>RW</strong></label>
      <input type="number" class="form-control" id="rw" placeholder="<?= $data['mhs']['rw'];?>" disabled>
    </div>

    

    <div class="form-group col-md-6">
      <label for="nibu"><strong>Nama Ibu</strong></label>
      <input type="text=" class="form-control" id="nibu" placeholder="<?= $data['mhs']['nibu'];?>" disabled>
    </div>

    

    <div class="form-group col-md-6">
      <label for="ayah"><strong>Nama Ayah</strong></label>
      <input type="text" class="form-control" id="ayah" placeholder="<?= $data['mhs']['ayah'];?>" disabled>
    </div>

    

    <div class="form-group col-md-6">
      <label for="bidik"><strong>Bidik misi ?</strong></label>
      <input type="select" class="form-control" id="bidik" placeholder="<?= $data['mhs']['bidik'];?>" disabled>
    </div>

    <div class="form-group col-md-6">
      <label for="lulusan"><strong>lulusan</strong></label>
      <input type="number" class="form-control" id="lulusan" placeholder="<?= $data['mhs']['lulusan'];?>" disabled>
    </div>
    
    
    
  </div>
 <br>


 
  <center><a href="<?=BASEURL;?>/mahasiswa" class="btn btn-primary">Kembali
  </a>
   <a href="<?=BASEURL;?>/edit" class="btn btn-Danger">Home
  </a>

  

  	
  </center>

</body>
</html>	

