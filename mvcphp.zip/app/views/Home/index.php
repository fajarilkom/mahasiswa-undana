<div class ="footer1 container">
	<div class="jumbotron mt-4">
		<div align="center">
			<h1 class="mt-3">Sistem Informasi Data Mahasiswa Kota Kupang</h1>
			<p class="lead">Ilmu Komputer Fakultas Sains dan Teknik</p>
			<a  class="btn btn-success btn-lg" href="#" role="button">Login</a>
		</div>
	</div>

	<div class="row">
		<div align="center" class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
			<div class="card" style="width: 18rem;">
				<img class="card-img-top" src="http://localhost/MVCPHP/public/img/images1.jpg" width="200" height="150" alt="Card image cap">
				<div class="card-body">
					<p class="card-text">Mahasiswa Undana Melakukan Upacara bendera 17 agustus didepan BAAK baru memakaai kain adat</p>
				</div>
			</div>
		</div>
		<div align="center" class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
			<div class="card" style="width: 18rem;">
				<img class="card-img-top" src="http://localhost/MVCPHP/public/img/images2.jpg" width="200" height="150" alt="Card image cap">
				<div class="card-body">
					<p align="left" class="card-text">Universitas Nusa Cendana merupakan kampus terbik di Kota Kupang , Universitas ini banyak diminati mahasiswa di Kota Kupang </p>
				</div>
			</div>
		</div>
		<div align="center" class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
			<div class="card" style="width: 18rem;">
				<img class="card-img-top" src="http://localhost/MVCPHP/public/img/images3.jpg" width="200" height="150" alt="Card image cap">
				<div class="card-body">
					<p align="left" class="card-text">Mahasiswa bidik misi melakukan antre untuk mengisi data pribadi untuk melengkapi data data yang dibutuhkan</p>
				</div>
			</div>
		</div>
	</div>
</div>