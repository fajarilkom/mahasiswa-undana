<footer  class="mt-4 py-4 bg-light text-black-70">
	<div class="container text-center">
		<small>©Sistem Informasi Data Mahasiswa Aktif Kota Kupang</small>
		<br><small>Fajar Subiantoro</small></br>
	</div>
</footer>

<script
			  src="https://code.jquery.com/jquery-3.4.1.js"
			  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
			  crossorigin="anonymous"></script><script src="http://localhost/mvcphp/public/js/popper.min.js"></script>
<script src="<?= BASEURL ?>/js/bootstrap.js"></script>
    
<script src="<?= BASEURL ?>/js/script.js"></script>
</body>
</html>
