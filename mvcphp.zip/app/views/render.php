<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
	
<body>
		<h1 align="center"><?php echo $title ?></h1>
</body>
</html>