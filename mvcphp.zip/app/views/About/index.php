<div class ="container">
	<div class="jumbotron mt-4">

		<div align="center">
			<div class="card" style="width: 18rem;">
				<img class="card-img-top" src="http://localhost/MVCPHP/public/img/hitler.jpg" alt="Card image cap">
				<div class="card-body">
					<h5 class="card-title">ABOUT</h5>
					<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				</div>
				<ul class="list-group list-group-flush">
					<li class="list-group-item">Nama : <?=$data['n'];?> </li>
					<li class="list-group-item">Pekerjaan : <?=$data['k'];?> </li>
					<li class="list-group-item">Umur : <?=$data['u'];?> </li>
				</ul>
			</div>
		</div>
	</div>
</div>