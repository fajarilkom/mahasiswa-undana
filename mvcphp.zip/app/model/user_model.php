<?php
class User_model{
	private $nama ='Fajar Subiantoro';
	public function getUser()
	{
		return $this->nama;
	}
}
