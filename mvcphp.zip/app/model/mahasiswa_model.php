<?php
class Mahasiswa_model{ //membuat class mahaiswa
	private $table ='mahasiswa'; //table
	private $db; //database
	public function __construct()
	{		//data source name
		$this->db = new database;
	}
	public function getAllMahasiswa()
	{
		$this->db->query('SELECT * FROM '. $this->table);
		return $this->db->resultSet();
	}
	public function getMahasiswaById($id)
	{
		$this->db->query('SELECT * FROM mahasiswa WHERE id=:id');
		$this->db->bind('id',$id);
		return $this->db->single();
	}

	public function hapusDataMahasiswa($id)
	{
		$query = " DELETE FROM mahasiswa WHERE id = :id";
		$this->db->query($query);
		$this->db->bind('id',$id);

		$this->db->execute();
		return $this->db->rowCount();

	}

	public function tambahDataMahasiswa($data)
	{
		$query = "INSERT INTO mahasiswa 
		VALUES 
		('', :nim, :nama,:jk, :asal, :jurusan, :email, :semester, :alamat, :kelurahan, :kecamatan, :provinsi,:rt, :rw, :nibu, :ayah, :bidik, :lulusan )";
		$this->db->query($query);
		$this->db->bind('nim',$data['nim']);
		$this->db->bind('nama',$data['nama']);
		$this->db->bind('jk',$data['jk']);
		$this->db->bind('asal',$data['asal']);
		$this->db->bind('jurusan',$data['jurusan']);
		$this->db->bind('email',$data['email']);
		$this->db->bind('semester',$data['semester']);
		$this->db->bind('alamat',$data['alamat']);
		$this->db->bind('kelurahan',$data['kelurahan']);
		$this->db->bind('kecamatan',$data['kecamatan']);
		$this->db->bind('provinsi',$data['provinsi']);
		$this->db->bind('rt',$data['rt']);
		$this->db->bind('rw',$data['rw']);
		$this->db->bind('nibu',$data['nibu']);
		$this->db->bind('ayah',$data['ayah']);
		$this->db->bind('bidik',$data['bidik']);
		$this->db->bind('lulusan',$data['lulusan']);
		$this->db->execute();
		return $this->db->rowCount();
	
	}	

	public function ubahDataMahasiswa($data){
        $query = "UPDATE mahasiswa SET
                nim = :nim,
                nama = :nama,
                jk = :jk,
                asal = :asal,
                jurusan = :jurusan,
                email = :email,
                semester = :semester,
                alamat = :alamat,
                kelurahan = :kelurahan,
                kecamatan = :kecamatan,
                provinsi = :provinsi,
                rt = :rt,
                rw = :rw,
                nibu = :nibu,
                ayah = :ayah,
                bidik = :bidik,
                lulusan = :lulusan
                WHERE nim = :nim";        
        $this->db->query($query);
        $this->db->bind('nim',$data['nim']);
        $this->db->bind('nama',$data['nama']);
        $this->db->bind('jk',$data['jk']);
        $this->db->bind('asal',$data['asal']);
        $this->db->bind('jurusan',$data['jurusan']);
        $this->db->bind('email',$data['email']);
        $this->db->bind('semester',$data['semester']);
        $this->db->bind('alamat',$data['alamat']);
        $this->db->bind('kelurahan',$data['kelurahan']);
        $this->db->bind('kecamatan',$data['kecamatan']);
        $this->db->bind('provinsi',$data['provinsi']);
        $this->db->bind('rt',$data['rt']);
        $this->db->bind('rw',$data['rw']);
        $this->db->bind('nibu',$data['nibu']);
        $this->db->bind('ayah',$data['ayah']);
        $this->db->bind('bidik',$data['bidik']);
        $this->db->bind('lulusan',$data['lulusan']);
        $this->db->execute();
        return $this->db->rowCount();
    }
}