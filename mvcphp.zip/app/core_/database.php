<?php
 class database{
	 private $host = DB_HOST;
	 private $user = DB_USER;
	 private $pass = DB_PASS;
	 private $db_name = DB_NAME;
	
	//variabel koneksi
	 private $dbh;
	 private $stmt;
	 //construct
	 public function __construct(){
	$dsn = 'mysql:host=' . $this->host . '; dbname=' . $this->db_name;
		 $option =[PDO::ATTR_PERSISTENT => true,
		 PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		 ]; 
//membuat koneksi database terjaga
		try{
			$this->dbh= new PDO($dsn,$this->user,$this->pass,$option);
//ubah user dan pass dan tambah parameter option untuk optimasi ke database
		} catch(PDOException $e){
			die($e->getMessage());
			}
		 
	 }
	 
	 public function query($query)
	 {
		 $this->stmt = $this->dbh->prepare($query);//penyiapan query untuk select, insert, update, delete untuk wrapper agar fleksbel
	 }
	 public function bind($param,$value,$type=null){
		 if (is_null($type)){
			 switch(true){
			 case is_int($value) :
			 $type = PDO::PARAM_INT;
			 break; //jika tipe data integer
			 case is_bool($value) :
			 $type = PDO::PARAM_BOOL;
			 break; //jika tipe data boolean
			 case is_null($value) :
			 $type = PDO::PARAM_NULL;
			 break; //jika value null maka param null
			 default :
			 $type = PDO::PARAM_STR;//value string
		 }
	 }
	 $this->stmt->bindValue($param, $value, $type); //cek apakah ada where atau parameter pencarian dan menghindari SQL injeksi karena query di eksekusi setelah string di bersihkan
 }
 public function execute(){
	 $this->stmt->execute(); //eksekusi
 }
 public function resultSet()
 {
	 $this->execute();
	 return $this->stmt->fetchAll(PDO::FETCH_ASSOC); //hasil banyak
 }  //untuk select */semua data
 public function single(){
	  $this->execute();
	 return $this->stmt->fetch(PDO::FETCH_ASSOC);
 } //untuk select satu data saja
 }	
