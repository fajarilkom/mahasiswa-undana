<?php
define('BASEURL','http://localhost/mvcphp/public');