
<div class="container">
  <br>
  <center><h2>DATA MAHASISWA</h2>
  <p>Data Mahasiswa Diwilayah Kota Kupang</p></center>        
  <form>
  <form>
  <div class="form-row">

    <div class="form-group col-md-6">
      <label for="nama"><strong>Nama lengkap</strong></label>
      <input type="text" class="form-control"   id="nama" placeholder="<?= $data['mhs']['nama'];?>"  disabled>
    </div>

    <div class="form-group col-md-6">
     <label for="namapdk"><strong>Nim</strong></strong></label>
      <input type="text" class="form-control" id="namapdk" placeholder="<?= $data['mhs']['nim'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="Nama"><strong>Asal</strong></label>
      <input type="asal" class="form-control" id="inputEmail4" placeholder="<?= $data['mhs']['asal'];?>" disabled>
    </div>
    
    <div class="form-group col-md-6">
     <label for="namapanggil"><strong>Jurusan</strong></strong></label>
      <input type="Lahir" class="form-control" id="inputPassword4" placeholder="<?= $data['mhs']['jurusan'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="Nama"><strong>Semester</strong></label>
      <input type="Umur" class="form-control" id="inputEmail4" placeholder="<?= $data['mhs']['semester'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="Nama"><strong>Jenis Kelamin</strong></label>
      <input type="Umur" class="form-control" id="inputEmail4" placeholder="<?= $data['mhs']['jk'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="Nama"><strong>Alamat</strong></label>
      <input type="Umur" class="form-control" id="inputEmail4" placeholder="<?= $data['mhs']['alamat'];?>" disabled>
    </div>
    <div class="form-group col-md-6">
      <label for="Nama"><strong>Kelurahan</strong></label>
      <input type="Umur" class="form-control" id="inputEmail4" placeholder="<?= $data['mhs']['kelurahan'];?>" disabled>
    </div>
    
    
    
  </div>


