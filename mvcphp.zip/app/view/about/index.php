<div class ="container">
<div class="jumbotron mt-4">
<p> About You</p>
<img src="<?=BASEURL;?>/img/default.jpg" alt="a"
width="200" class="rounded-circle shadow" >
<p>Nama saya <?=$data['n'];?>, Kerja <?=$data['k'];?>, Umur <?=$data['u'];?><p>
</div>
</div>
