<!DOCTYPE html>

// <html>
// <head>
	// <title>Halaman Home/About/Page</title>
// </head>
// <body>
// <h1> Selamat Datang di PHP MVC! /About Me/My Page</h1>
// </body>
// </html>

<p>Pages OK</p>