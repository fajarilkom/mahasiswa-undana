<div class ="container">
<div class="jumbotron mt-4">
  <h1 class="mt-3">Selamat Datang di PHP MVC!</h1>
  <p class="lead">Belajar Dasar OOP PHP dengan konsep MVC.</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>
</div>
