<!DOCTYPE html>
<html>
<head>
<title> Halaman About</title>
</head>
<body>
<p> About You</p>
<p>Nama saya <?=$data['n'];?>, Kerja <?=$data['k'];?>, Umur <?=$data['u'];?><p>
</body>
</html>
