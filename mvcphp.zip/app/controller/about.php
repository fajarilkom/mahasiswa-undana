<?php

class About  extends Controller{
public function index($n = "Fajar Subaintoro", $k = "Mahasiswa", $u = "20 tahun")
{
	$data['n']=$n;
	$data['k']=$k;
	$data['u']=$u;
	$this->views('templates/header', $data);
	$this->views('about/index',$data);
	
	$this->views('templates/footer');

	//echo "<br>"; echo "Hallo"; echo "<br>";
	//echo "Nama Saya  $n, Hobby $k dan Saya berusia $u tahun";
}
public function page() 
{
	$data['judul']='Page';
	$this->views('templates/header', $data);
	$this->views('about/page');
	$this->views('templates/footer');
//echo 'page/index';
}

}