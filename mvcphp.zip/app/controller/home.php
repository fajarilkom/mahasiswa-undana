<?php 
class Home extends Controller{
	public function index()	{
	$data['judul']='Home';
	$data['nama'] = $this->model('User_model')->getuser();
	$this->views('templates/header',$data);	
	$this->views('home/index',$data);
	$this->views('templates/footer');  } }

