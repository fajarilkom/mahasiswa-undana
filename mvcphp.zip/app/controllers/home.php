<?php
class Home extends controller
{	
	public function index()
	{
		$data['judul']='Home';
		$this->views('templates/header',$data);	
		$this->views('home/index',$data);
		$this->views('templates/footer');

		//$this->views('home/index'); 
		//echo "home/index";
	}
}