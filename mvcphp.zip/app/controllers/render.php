<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->qrcode('Ciqrcode');
	}
	public function index()
	{
		$data['title'] = "CONTOH QR CODE nya coba coba latihan";
		$this->load->views('render', $data);
	}

	public function QRcode($kodenya = '123456789')
	{
		QRcode::png(
				$kodenya,
				$outfile = false,
				$level = QR_ECLEVEL_H,
				$size = 5,
				$margin = 2

		);
	}
}