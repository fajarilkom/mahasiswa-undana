<?php
class About extends Controller 
{
	public function index($n="Hitler",$k="Diktator", $u="> 100")
	{
		$data['n']=$n;
		$data['k']=$k;
		$data['u']=$u;
		$data['judul']='About';
		$this->views('templates/header',$data);	
		$this->views('about/index',$data);
		$this->views('templates/footer');
	}

	public function page($n="Hitler",$k="Diktator", $u="> 100")
	{
		$data['n']=$n;
		$data['k']=$k;
		$data['u']=$u;
		$data['judul']='Page';
		$this->views('templates/header',$data);	
		$this->views('about/page',$data);
		$this->views('templates/footer');
	}
}