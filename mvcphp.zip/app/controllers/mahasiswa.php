<?php
class Mahasiswa extends Controller{ //buat kelas mahasiswa
	public function index()
		{ //method default
			$data['judul']= 'Daftar Mahasiswa';
			$data['mhs']=$this->model('mahasiswa_model')->getAllMahasiswa();
			$this->views('templates/header',$data);
			$this->views('Mahasiswa/index',$data);
			$this->views('templates/footer');
		}
public function detail($id){ //method default
	$data['judul']= 'Detail Mahasiswa';
	$data['mhs']=$this->model('mahasiswa_model')->getMahasiswaById($id);
	$this->views('templates/header',$data);
	$this->views('mahasiswa/detail',$data);
	$this->views('templates/footer');
}



public function tambah(){

	if($this->model('mahasiswa_model')->tambahDataMahasiswa($_POST) > 0){
		Flasher::setFlasher('berhasil','ditambahkan','success');
		header('Location: ' .BASEURL. '/mahasiswa');
		exit;
	}	
}
	
	public function hapus($id)
	{

	if( $this->model('mahasiswa_model')->hapusDataMahasiswa($id) > 0)
	{
		
		Flasher::setFlasher('berhasil','dihapus','success');
		header('Location: ' .BASEURL. '/mahasiswa');
		exit;
	} 
	else{
		Flasher::setFlasher('gagal','dihapus','danger');
		header('Location: ' . BASEURL . '/mahasiswa');
		exit;
	}
}
public function getubah()
 {
  echo json_encode($this->model('mahasiswa_model')->getMahasiswaById($_POST['id']));
 }
 public function ubah()
 {
 	if($this->model('mahasiswa_model')->ubahDataMahasiswa($_POST) > 0){
        header('Location: ' .BASEURL. '/mahasiswa');
        exit;

 } 
 }

 public function cetak($id)
{ 
	$data['mhs']=$this->model('mahasiswa_model')->getMahasiswaById($id);
	$this->views('Mahasiswa/cetak',$data);
}

 public function qrcode($id)
	{
		
		$data['mhs']=$this->model('mahasiswa_model')->getMahasiswaById($id);
	$this->views('Mahasiswa/qrcode',$data);
	}


}