$(function (){

	$('.tomboltambah').on('click', function(){

		$('#judulModal').html('Tambah Data Mahasiswa');
		$('.modal-footer button[type=submit]').html('Tambah Data');
		
	});

	$('.tampilModalUbah').on('click', function(){

		$('#judulModal').html('Ubah Data Mahasiswa');
		$('.modal-footer button[type=submit]').html('Ubah Data');
		$('.modal-body form').attr('action', 'http://localhost/mvcphp/public/mahasiswa/Ubah');
		const id = $(this).data('id');


		$.ajax({
			url: 'http://localhost/mvcphp/public/mahasiswa/getubah',
			data: {id : id},
			method: 'post',
			dataType: 'json', 
			success: function(data){
				$('#nim').val(data.nim);
				$('#nama').val(data.nama);
				$('#jk').val(data.jk);
				$('#asal').val(data.asal);
				$('#jurusan').val(data.jurusan);
				$('#email').val(data.email);
				$('#semester').val(data.semester);
				$('#alamat').val(data.alamat);
				$('#kelurahan').val(data.kelurahan);
				$('#kecamatan').val(data.kecamatan);
				$('#provinsi').val(data.provinsi);
				$('#rt').val(data.rt);
				$('#rw').val(data.rw);
				$('#nibu').val(data.nibu);
				$('#ayah').val(data.ayah);
				$('#bidik').val(data.bidik);
				$('#lulusan').val(data.lulusan); 
			}
			
		});
	});
});