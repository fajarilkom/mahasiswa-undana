<?php
require('fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->Image('undana1.png',15,10,'C');


$pdf->SetMargins(25,20,25);

$pdf->SetFont('Arial','B',12); 
$pdf->setTextColor(100, 0, 0);
$pdf->Cell(200,10,'KEMENTRIAN RISET,TEKNOLOGI DAN PENDIDIKAN TINGGI',40,40,'C');
$pdf->SetFont('Arial','B',25); 
$pdf->Cell(200,5,'UNIVERSITAS NUSA CENDANA',40,40,'C');
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(200,8,'Jl. Adisucipto, Penfui, Kotak Pos 104, Kupang 85001. NTT',40,40,'C');
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(200,2,'Email : baakpsi_undana@yahoo.com, Telp (0380)881580. Fax 881674-881586',40,40,'C');
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(200,8,'Website: http://www.undana.ac.id',40,40,'C');
$pdf->Cell(150,5, '', 0,1);
$pdf->Line(20,45,190,45);
	



$pdf->SetFont('Arial','B',13); 
$pdf->Cell(160,30,'DATA MAHASISWA UNIVERSITAS NUSA CENDANA (UNDANA) KUPANG',0,1,'C');

$pdf->SetFont('Arial','',12);
$pdf->Cell(150,5, 'Berikut Adalah data mahasiswa AKTIF yang sedang aktif berkuliah di Universitas Nusa ', 0,01);
$pdf->Cell(150,5, 'Cendana (UNDANA) dengan biodata sebagai berikut :', 0,1);
$pdf->Cell(150,5, '', 0,1);

$pdf->SetFont('Arial','B',12);
$pdf->Cell(10,1, '', 0,01);
$pdf->Cell(50,10, 'DATA PRIBADI', 0,01);

$pdf->SetFont('Arial','',12);
$pdf->Cell(50,10, 'NIM');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['nim'], 0,01);

$pdf->Cell(50,10, 'Nama');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['nama'], 0,01);

$pdf->Cell(50,10, 'Jenis Kelamin');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['jk'], 0,01);

$pdf->Cell(50,10, 'Asal');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(28,10, $data['mhs']['asal'], 0,01);

$pdf->Cell(50,10, 'Jurusan');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['jurusan'], 0,01);

$pdf->Cell(50,10, 'E-Mail');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['email'], 0,01);

$pdf->Cell(50,10, 'Semester');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['semester'], 0,01);


$pdf->SetFont('Arial','B',12);
$pdf->Cell(50,10, 'ALAMAT', 0,01);
$pdf->SetFont('Arial','',12);
$pdf->Cell(50,10, 'Alamat');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['alamat'], 0,01);

$pdf->Cell(50,10, 'Kelurahan');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['kelurahan'], 0,01);

$pdf->Cell(50,10, 'Kecamatan');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['kecamatan'], 0,01);

$pdf->Cell(50,10, 'Provinsi');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['provinsi'], 0,01);

$pdf->Cell(50,10, 'RT');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['rt'], 0,01);

$pdf->Cell(50,10, 'RW');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['rw'], 0,01);


$pdf->AddPage();
$pdf->SetFont('Arial','B',12);


$pdf->SetFont('Arial','B',12);
$pdf->Cell(50,10, 'DATA ORANGTUA', 0,01);
$pdf->SetFont('Arial','',12);
$pdf->Cell(50,10, 'Nama Ibu');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['nibu'], 0,01);

$pdf->Cell(50,10, 'Nama Ayah');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['ayah'], 0,01);


$pdf->SetFont('Arial','B',12);
$pdf->Cell(50,10, 'DATA PENDUKUNG', 0,01);

$pdf->SetFont('Arial','',12);
$pdf->Cell(50,10, 'Bidik misi ?');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['bidik'], 0,01);

$pdf->Cell(50,10, 'Tahun Lulus');
$pdf->Cell(10,10, ' : ');
$pdf->Cell(50,10, $data['mhs']['lulusan'], 0,01);


$pdf->Cell(50,10, '', 0,01);

$pdf->Cell(50,10, '', 0,01);
$pdf->SetFont('Arial','',13);
$pdf->Cell(50,5, 'Print 5 lembar dan diberikan Kepada :', 0,01);
$pdf->Cell(50,10, '', 0,01);
$pdf->Cell(50,5, '1. Kemahasiswaan',0,01);
$pdf->Cell(50,5, '2. Fakultas', 0,1);
$pdf->Cell(50,5, '3. Jurusan', 0,01);
$pdf->Cell(50,5, '2. Dosen Pembimbing', 0,1);
$pdf->Cell(50,5, '3. Mahasiswa', 0,01);

$pdf->Cell(10,10, '', 0,01);

$pdf->Cell(50,10, '', 0,01);



$pdf->Cell(160,5, '', 0,1);
$pdf->Cell(160,5, '', 0,1);



$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, 'Dosen Pembimbing', 0,1,'C');
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, ('.....................'), 0,1, 'C');

$pdf->Cell(50,10, '', 0,01);

$pdf->Cell(160,5, '', 0,1);
$pdf->SetMargins(140,25,25);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,-100, 'Mahasiswa', 0,1,'C');
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,5, '', 0,1);
$pdf->Cell(50,110, ($data['mhs']['nama']), 0,1, 'C');




$pdf->Cell(-70,-20, 'Kupang, 15 Agustus 2019', 0,1,'C');

$pdf->Image('qrcode.png',95,250,'C');

$pdf->Output('I','pdf');

?>
